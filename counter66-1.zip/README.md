# counter66
A Discord bot that adds in a counting channel.

Project ran by @Parv66
