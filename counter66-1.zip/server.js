let Discord = require("discord.js")
const client = new Discord.Client()
const { data } = require('./config.json')

client.on("ready", async () => {
  console.log("Running!")
});

client.on("message", async message => {
    message.channel.send('Pong!')
  })


 command(client, ['ping', 'test'], (message) => {
    message.channel.send('Pong!')
  })


client.login(process.data.botToken);
